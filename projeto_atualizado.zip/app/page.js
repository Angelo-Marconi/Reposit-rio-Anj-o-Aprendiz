"use client";

import { useState } from "react";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Table } from "@/components/ui/table";
import logo from "../public/logo.png";

const initialGuests = [];

export default function Home() {
  const [guests, setGuests] = useState(initialGuests);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("");
  const [eventTitle, setEventTitle] = useState("Casamento de ...");
  const [isAdmin, setIsAdmin] = useState(true);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      const csv = e.target.result;
      const lines = csv.split("\n");
      const newGuests = lines.slice(1).map((line) => {
        const [name, category] = line.split(",");
        return { name, category, confirmed: false };
      });
      setGuests(newGuests);
    };
    reader.readAsText(file);
  };

  const toggleConfirmation = (index) => {
    setGuests((prev) =>
      prev.map((guest, i) =>
        i === index ? { ...guest, confirmed: !guest.confirmed } : guest
      )
    );
  };

  const filteredGuests = guests.filter((guest) =>
    guest.name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 text-center">
      <Image src={logo} alt="Recanto dos Lagos Cerimonial" width={200} height={100} className="mx-auto mb-4" />
      {isAdmin && (
        <input
          type="text"
          value={eventTitle}
          onChange={(e) => setEventTitle(e.target.value)}
          className="text-xl font-bold mb-4 text-center border border-gray-300 p-2 rounded"
        />
      )}
      {!isAdmin && <h1 className="text-2xl font-bold mb-4">{eventTitle}</h1>}
      <input type="file" accept=".csv" onChange={handleFileUpload} className="mb-4" />
      <Input
        placeholder="Buscar por nome"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-4"
      />
      <div className="space-y-4">
        <Table>
          <thead>
            <tr>
              <th>Nome</th>
              <th>Categoria</th>
              <th>Confirmação</th>
            </tr>
          </thead>
          <tbody>
            {filteredGuests.map((guest, index) => (
              <tr key={index}>
                <td>{guest.name}</td>
                <td>{guest.category}</td>
                <td>
                  <Button
                    onClick={() => toggleConfirmation(index)}
                    className={guest.confirmed ? "bg-green-500" : "bg-gray-300"}
                  >
                    {guest.confirmed ? "Confirmado" : "Confirmar"}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
}